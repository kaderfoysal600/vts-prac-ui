import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { PermissionGroupItemDialogComponent } from 'src/app/dialog/permission-group-item-dialog/permission-group-item-dialog.component';
import { AuthService } from 'src/app/service/auth.service';
import { UiService } from 'src/app/service/ui.service';

@Component({
  selector: 'app-list-permission-group-item',
  templateUrl: './list-permission-group-item.component.html',
  styleUrls: ['./list-permission-group-item.component.scss']
})
export class ListPermissionGroupItemComponent implements OnInit {

  allPermissionGroupItem
  private subDataTwo: Subscription;
  constructor(
    private authService: AuthService,
    private dialog: MatDialog,
    private uiService: UiService,
  ) { }

  ngOnInit(): void {
    this.getAllPermissionGroupItem()
    console.log('allPermissionGroup Item', this.allPermissionGroupItem
    );

  }


  getAllPermissionGroupItem() {
    this.authService.getAllPermissionGroupItem().subscribe({
      next: (res) => {
        if (res) {
          this.allPermissionGroupItem = res
          console.log(res)

        } else {
          console.log('Error! Please try again.')
        }
      },
      error: (err) => {
        console.log(err)
      }
    })
  }

  public openEditControllerDialog(data?: any) {
    const dialogRef = this.dialog.open(PermissionGroupItemDialogComponent, {
      maxWidth: '600px',
      width: '95%',
      data: data,
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe((dialogResult) => {
      if (dialogResult && dialogResult.data) {
        if (data) {
          this.updatePermissionGroupItem(data.id, dialogResult.data);
        } else {
          this.addPermissionGroupItem(dialogResult.data);
        }
      }
    });
  }


  addPermissionGroupItem(data: any) {
    this.subDataTwo = this.authService.addPermissionGroupItem(data)
      .subscribe({
        next: (res) => {
          if (res) {
            console.log('Permission Group Item added successfully')
            this.uiService.success('Permission Group Item added successfully');
            this.getAllPermissionGroupItem()
          } else {
            console.log('Error! Please try again.')
          }
        },
        error: (err) => {
          console.log(err)
        }
      })
  }



  public updatePermissionGroupItem(id: string, data: any) {
    this.authService.updatePermissionGroupItem(id, data).subscribe({
      next: (res) => {
        console.log(res);
        this.uiService.success('Permission Group Item Updated successfully');
        if (res) {
          this.getAllPermissionGroupItem()
        }
      },
      error: (err) => {
        console.log(err);
      },
    });
  }


  deletePermissionGroupItem(id: string) {
    this.authService.deletePermissionGroupItem(id).subscribe({
      next: (res) => {
        console.log(res);
        this.uiService.success('Permission Group Item deleted successfully');
        if (res) {
          this.getAllPermissionGroupItem()
        }
      },
      error: (err) => {
        console.log(err);
      },
    });
  }

}
